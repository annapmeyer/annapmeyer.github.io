/* You will add your code in this file. 

   For part 1, *do not* change anything about the struct definition or 
   the typedef in this file.
   
   For part 2, you will delete the struct definition and typedef in this file.  
*/

struct Vector
{
    // A pointer to a traditional C array to hold data
    int *array;

    // The size of the actual C array that you have allocated
    int memorySize;

    // The virtual size of the vector, i.e. how much data is in it
    // from the user's perspective
    int size;
};

/* It is cumbersome to type "struct Vector" all the time. This creates a shortcut so that
   you can just type "Vector" instead. */
typedef struct Vector Vector;

