(if #t 5 12)
(if #t 9 12)
