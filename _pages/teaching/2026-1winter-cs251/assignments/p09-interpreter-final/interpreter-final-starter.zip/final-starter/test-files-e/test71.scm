(define x 3)
