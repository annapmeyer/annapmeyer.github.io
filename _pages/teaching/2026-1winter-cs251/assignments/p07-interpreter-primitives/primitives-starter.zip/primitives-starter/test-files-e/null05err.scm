(null? (quote ()) (quote ()))
