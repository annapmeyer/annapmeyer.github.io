(null? 3)
