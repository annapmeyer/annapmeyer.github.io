(null? (quote ()))
