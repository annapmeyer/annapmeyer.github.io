// Tester for linked list.

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <assert.h>
#include "linkedlist.h"
#include "schemeitem.h"
#include "talloc.h"

void testForward(SchemeItem *head, int correctLength, bool exemplary) {
  SchemeItem *item = head;
  assert(CONS_TYPE == item->type);
  assert(REAL_TYPE == car(item)->type);
  assert(1 == car(item)->r);

  if (exemplary) {
    item = cdr(item);
    assert(CONS_TYPE == item->type);
    assert(STR_TYPE == car(item)->type);
    assert(!strcmp("2.0s", car(item)->s));

    item = cdr(item);
    assert(CONS_TYPE == item->type);
    assert(STR_TYPE == car(item)->type);
    assert(!strcmp("3.0s", car(item)->s));
  }

  item = cdr(item);
  assert(CONS_TYPE == item->type);
  assert(REAL_TYPE == car(item)->type);
  assert(4 == car(item)->r);

  if (exemplary) {
    item = cdr(item);
    assert(CONS_TYPE == item->type);
    assert(STR_TYPE == car(item)->type);
    assert(!strcmp("5.0s", car(item)->s));
  }

  item = cdr(item);
  assert(CONS_TYPE == item->type);
  assert(REAL_TYPE == car(item)->type);
  assert(6 == car(item)->r);

  item = cdr(item);
  assert(CONS_TYPE == item->type);
  assert(INT_TYPE == car(item)->type);
  assert(7 == car(item)->i);

  item = cdr(item);
  assert(NULL_TYPE == item->type);

  assert(correctLength == length(head));
  assert(!isNull(head));
}

void testBackward(SchemeItem *head, int correctLength, bool exemplary) {
  SchemeItem *item = head;

  assert(CONS_TYPE == item->type);
  assert(INT_TYPE == car(item)->type);
  assert(7 == car(item)->i);

  item = cdr(item);
  assert(CONS_TYPE == item->type);
  assert(REAL_TYPE == car(item)->type);
  assert(6 == car(item)->r);

  if (exemplary) {
    item = cdr(item);
    assert(CONS_TYPE == item->type);
    assert(STR_TYPE == car(item)->type);
    assert(!strcmp("5.0s", car(item)->s));
  }

  item = cdr(item);
  assert(CONS_TYPE == item->type);
  assert(REAL_TYPE == car(item)->type);
  assert(4 == car(item)->r);

  if (exemplary) {
    item = cdr(item);
    assert(CONS_TYPE == item->type);
    assert(STR_TYPE == car(item)->type);
    assert(!strcmp("3.0s", car(item)->s));

    item = cdr(item);
    assert(CONS_TYPE == item->type);
    assert(STR_TYPE == car(item)->type);
    assert(!strcmp("2.0s", car(item)->s));
  }

  item = cdr(item);
  assert(CONS_TYPE == item->type);
  assert(REAL_TYPE == car(item)->type);
  assert(1 == car(item)->r);

  item = cdr(item);
  assert(NULL_TYPE == item->type);

  assert(correctLength == length(head));
  assert(!isNull(head));
}


int main(int argc, char **argv) {

  bool exemplary = false;
  if (argc == 2 && !strcmp(argv[1], "E")) {
    exemplary = true;
  }

  SchemeItem *head = makeNull();
  int correctLength = 0;

  SchemeItem *item1 = talloc(sizeof(SchemeItem));
  item1->type = INT_TYPE;
  item1->i = 7;
  head = cons(item1,head);
  correctLength++;

  SchemeItem *item2 = talloc(sizeof(SchemeItem));
  item2->type = REAL_TYPE;
  item2->r = 6.00;
  head = cons(item2,head);
  correctLength++;

  if (exemplary) {
    SchemeItem *item3 = talloc(sizeof(SchemeItem));
    item3->type = STR_TYPE;
    char *text = "5.0s";
    item3->s = talloc(sizeof(char)*(strlen(text) + 1));
    strcpy(item3->s, text);
    head = cons(item3,head);
    correctLength++;
  }

  SchemeItem *item4 = talloc(sizeof(SchemeItem));
  item4->type = REAL_TYPE;
  item4->r = 4.00000;
  head = cons(item4,head);
  correctLength++;

  if (exemplary) {
    SchemeItem *item5 = talloc(sizeof(SchemeItem));
    item5->type = STR_TYPE;
    char *text = "3.0s";
    item5->s = talloc(sizeof(char)*(strlen(text) + 1));
    strcpy(item5->s, text);
    head = cons(item5,head);
    correctLength++;

    SchemeItem *item6 = talloc(sizeof(SchemeItem));
    item6->type = STR_TYPE;
    text = "2.0s";
    item6->s = talloc(sizeof(char)*(strlen(text) + 1));
    strcpy(item6->s, text);
    head = cons(item6,head);
    correctLength++;
  }

  SchemeItem *item7 = talloc(sizeof(SchemeItem));
  item7->type = REAL_TYPE;
  item7->r = 1.0;
  head = cons(item7,head);
  correctLength++;
    
  display(head);
  testForward(head, correctLength, exemplary);

  SchemeItem *rev = reverse(head);
  display(rev);

  testBackward(rev, correctLength, exemplary);

  // Verify that neither of the lists share identical cons cells
  SchemeItem *headcur = head;
  while (headcur->type != NULL_TYPE) {
    SchemeItem *revcur = rev;
    while (revcur->type != NULL_TYPE) {
      assert(headcur != revcur);
      revcur = revcur->cdr;
    }
    headcur = headcur->cdr;
  }

  if (exemplary) {
    printf(" -=- EMPTY LIST -=- \n");
    SchemeItem *emptyList = makeNull();
    assert(0 == length(emptyList));
    assert(isNull(emptyList));

    printf(" -=- REVERSE EMPTY LIST -=- \n");
    SchemeItem *reverseEmpty = reverse(emptyList);
    assert(0 == length(reverseEmpty));
    assert(isNull(reverseEmpty));

    SchemeItem *justOneByte = talloc(1);
  }

  tfree();

  SchemeItem *justOneByte = talloc(1);
  texit(0);
}
