;; DO NOT CHANGE THESE TESTS.

;; Module to include testing code
(use-modules (srfi srfi-64))

(test-equal 1 (multiply '()))

;; Assignment specifies full list for n > len(list)
(test-equal '(a b c d e) (keep-first-n 6 '(a b c d e)))
;; Assignment specifies empty list for n <= 0
(test-equal '() (keep-first-n -1 '(a b c d e)))
(test-equal '() (keep-first-n 0 '(a b c)))



