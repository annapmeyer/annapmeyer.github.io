(lambda (()) 9)
