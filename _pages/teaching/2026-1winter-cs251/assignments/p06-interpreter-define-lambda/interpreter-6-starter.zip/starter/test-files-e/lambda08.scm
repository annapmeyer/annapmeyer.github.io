(lambda (x) y)
