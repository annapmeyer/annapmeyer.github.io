(define x x)
