((lambda () 23))
