#ifndef _SCHEMEITEM
#define _SCHEMEITEM

typedef enum {
   INT_TYPE, REAL_TYPE, STR_TYPE, CONS_TYPE, NULL_TYPE, PTR_TYPE,
   OPEN_TYPE, CLOSE_TYPE, BOOL_TYPE, SYMBOL_TYPE, SINGLEQUOTE_TYPE,
    
   // Types below are only for bonus work
   DOT_TYPE, OPENBRACKET_TYPE, CLOSEBRACKET_TYPE
} itemType;

typedef struct SchemeItem {
    itemType type;
    union {
        int i;
        double r;
        char *s;
        struct {
            struct SchemeItem *car;
            struct SchemeItem *cdr;
        };
        void *ptr;
    };
} SchemeItem;

#endif
