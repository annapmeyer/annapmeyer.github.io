
;; This function is used for some of the later tasks.
;; Ignore it until the activity mentions it.
(define cons-each
    (lambda (item lst)
        (if (null? lst)
            '()
            (cons (cons item (car lst))
                  (cons-each item (cdr lst))))))