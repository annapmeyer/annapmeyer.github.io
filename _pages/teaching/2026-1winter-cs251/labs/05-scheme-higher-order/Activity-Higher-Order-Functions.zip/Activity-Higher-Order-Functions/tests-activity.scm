;; For this activity, you're welcome and encouraged
;; to add to these tests - they provide only 
;; very minimal starting point in their current form.
;; (But remember, for homework, we always run your
;; code on the original versions of the tests.)

;; Module to include testing code
(use-modules (srfi srfi-64))

;; Here's an example of taking one of input/output
;; pairs from the activity and turning it into a test.
;; The line from the activity was:
;; (fold-left + 3 '(7 0 4)) ;; Returns 14
;; I've changed the function name to fold-l (matching
;; the name of your implementation). test-equal will
;; be a passing test if the return value of 
;; (fold-l + 3 '(7 0 4)) is equal to 14.
(test-equal 14 (fold-l + 3 '(7 0 4)))

;; Add additional tests here!




