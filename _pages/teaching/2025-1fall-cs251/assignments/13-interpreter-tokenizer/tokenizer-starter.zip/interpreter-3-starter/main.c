#include <stdio.h>
#include "tokenizer.h"
#include "schemeitem.h"
#include "linkedlist.h"
#include "talloc.h"

int main() {
    SchemeItem *list = tokenize();
    displayTokens(list);
    tfree();
}
