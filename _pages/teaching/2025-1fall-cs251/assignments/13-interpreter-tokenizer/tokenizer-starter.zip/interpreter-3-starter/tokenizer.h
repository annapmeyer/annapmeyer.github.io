#include "schemeitem.h"

#ifndef TOKENIZER
#define TOKENIZER

// Read all of the input from stdin, and return a linked list consisting of the
// tokens.
SchemeItem *tokenize();

// Displays the contents of the linked list as tokens, with type information
void displayTokens(SchemeItem *list);

#endif
