// Tester for linked list.

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <assert.h>
#include "linkedlist.h"
#include "schemeitem.h"

void testForward(SchemeItem *head, int correctLength, bool exceeds_expectations) {
  SchemeItem *object = head;
  assert(CONS_TYPE == object->type);
  assert(DOUBLE_TYPE == car(object)->type);
  assert(1 == car(object)->d);

  if (exceeds_expectations) {
    object = cdr(object);
    assert(CONS_TYPE == object->type);
    assert(STR_TYPE == car(object)->type);
    assert(!strcmp("2.0s", car(object)->s));

    object = cdr(object);
    assert(CONS_TYPE == object->type);
    assert(STR_TYPE == car(object)->type);
    assert(!strcmp("3.0s", car(object)->s));
  }

  object = cdr(object);
  assert(CONS_TYPE == object->type);
  assert(DOUBLE_TYPE == car(object)->type);
  assert(4 == car(object)->d);

  if (exceeds_expectations) {
    object = cdr(object);
    assert(CONS_TYPE == object->type);
    assert(STR_TYPE == car(object)->type);
    assert(!strcmp("5.0s", car(object)->s));
  }

  object = cdr(object);
  assert(CONS_TYPE == object->type);
  assert(DOUBLE_TYPE == car(object)->type);
  assert(6 == car(object)->d);

  object = cdr(object);
  assert(CONS_TYPE == object->type);
  assert(INT_TYPE == car(object)->type);
  assert(7 == car(object)->i);

  object = cdr(object);
  assert(EMPTY_TYPE == object->type);

  assert(correctLength == length(head));
  assert(!isEmpty(head));
}

void testBackward(SchemeItem *head, int correctLength, bool exceeds_expectations) {
  SchemeItem *item = head;

  assert(CONS_TYPE == item->type);
  assert(INT_TYPE == car(item)->type);
  assert(7 == car(item)->i);

  item = cdr(item);
  assert(CONS_TYPE == item->type);
  assert(DOUBLE_TYPE == car(item)->type);
  assert(6 == car(item)->d);

  if (exceeds_expectations) {
    item = cdr(item);
    assert(CONS_TYPE == item->type);
    assert(STR_TYPE == car(item)->type);
    assert(!strcmp("5.0s", car(item)->s));
  }

  item = cdr(item);
  assert(CONS_TYPE == item->type);
  assert(DOUBLE_TYPE == car(item)->type);
  assert(4 == car(item)->d);

  if (exceeds_expectations) {
    item = cdr(item);
    assert(CONS_TYPE == item->type);
    assert(STR_TYPE == car(item)->type);
    assert(!strcmp("3.0s", car(item)->s));

    item = cdr(item);
    assert(CONS_TYPE == item->type);
    assert(STR_TYPE == car(item)->type);
    assert(!strcmp("2.0s", car(item)->s));
  }

  item = cdr(item);
  assert(CONS_TYPE == item->type);
  assert(DOUBLE_TYPE == car(item)->type);
  assert(1 == car(item)->d);

  item = cdr(item);
  assert(EMPTY_TYPE == item->type);

  assert(correctLength == length(head));
  assert(!isEmpty(head));
}


int main(int argc, char **argv) {

  bool exceeds_expectations = false;
  if (argc == 2 && !strcmp(argv[1], "E")) {
    exceeds_expectations = true;
  }

  SchemeItem *head = makeEmpty();
  int correctLength = 0;
  assert(length(head) == correctLength);

  SchemeItem *reverseLengthZero = reverse(head);
  assert(length(reverseLengthZero) == correctLength);
  cleanup(reverseLengthZero);

  SchemeItem *item1 = malloc(sizeof(SchemeItem));
  item1->type = INT_TYPE;
  item1->i = 7;
  head = cons(item1,head);
  correctLength++;
  assert(length(head) == correctLength);

  SchemeItem *reverseLengthOne = reverse(head);
  assert(length(reverseLengthOne) == correctLength);
  cleanup(reverseLengthOne);

  SchemeItem *item2 = malloc(sizeof(SchemeItem));
  item2->type = DOUBLE_TYPE;
  item2->d = 6.00;
  head = cons(item2,head);
  correctLength++;
  assert(length(head) == correctLength);

  if (exceeds_expectations) {
    SchemeItem *item3 = malloc(sizeof(SchemeItem));
    item3->type = STR_TYPE;
    char *text = "5.0s";
    item3->s = malloc(sizeof(char)*(strlen(text) + 1));
    strcpy(item3->s,text);
    head = cons(item3,head);
    correctLength++;
    assert(length(head) == correctLength);
  }

  SchemeItem *item4 = malloc(sizeof(SchemeItem));
  item4->type = DOUBLE_TYPE;
  item4->d = 4.00000;
  item4 = cons(item4,head);
  correctLength++;
  assert(length(head) == correctLength);

  if (exceeds_expectations) {
    SchemeItem *item5 = malloc(sizeof(SchemeItem));
    item5->type = STR_TYPE;
    char *text = "3.0s";
    item5->s = malloc(sizeof(char)*(strlen(text) + 1));
    strcpy(item5->s,text);
    head = cons(item5,head);
    correctLength++;
    assert(length(head) == correctLength);

    SchemeItem *item6 = malloc(sizeof(SchemeItem));
    item6->type = STR_TYPE;
    text = "2.0s";
    item6->s = malloc(sizeof(char)*(strlen(text) + 1));
    strcpy(item6->s,text);
    head = cons(item6,head);
    correctLength++;
    assert(length(head) == correctLength);

  }

  SchemeItem *item7 = malloc(sizeof(SchemeItem));
  item7->type = DOUBLE_TYPE;
  item7->d = 1.0;
  head = cons(item7,head);
  correctLength++;
  assert(length(head) == correctLength);


  display(head);
  testForward(head, correctLength, exceeds_expectations);

  SchemeItem *rev = reverse(head);
  display(rev);

  testBackward(rev, correctLength, exceeds_expectations);

  cleanup(head);
  cleanup(rev);

  head = NULL;
  rev = NULL;
}
