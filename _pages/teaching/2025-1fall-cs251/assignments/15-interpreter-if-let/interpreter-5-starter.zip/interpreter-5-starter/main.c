#include <stdio.h>
#include "tokenizer.h"
#include "schemeitem.h"
#include "linkedlist.h"
#include "parser.h"
#include "talloc.h"

/* Main for parser */

int main() {

    SchemeItem *list = tokenize();
    SchemeItem *tree = parse(list);

    printTree(tree);
    printf("\n");

    tfree();
    return 0;
}
