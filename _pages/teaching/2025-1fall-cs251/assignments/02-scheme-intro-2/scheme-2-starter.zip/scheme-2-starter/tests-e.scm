;; DO NOT CHANGE THESE TESTS.

;; Module to include testing code
(use-modules (srfi srfi-64))

(test-equal 1 (multiply '()))

;; Assignment specifies empty list for too short/too long
(test-equal '() (keep-first-n '(a b c d e) 6))
(test-equal '() (keep-first-n '(a b c d e) -1))
(test-equal '() (keep-first-n '(a b c) 0))



