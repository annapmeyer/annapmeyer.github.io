;; DO NOT CHANGE THESE TESTS.

;; Module to include testing code
(use-modules (srfi srfi-64))


(test-equal 40 (multiply '(4 5 2 1)))
(test-equal 240 (multiply '(4 5 2 1 -2 -3)))
(test-equal -240 (multiply '(-4 5 2 1 -2 -3)))
(test-equal 3 (multiply '(3)))


(test-equal '(a b c) (keep-first-n '(a b c d e) 3))
(test-equal '(a b) (keep-first-n '(a b c d e) 2))
(test-equal '(a b c d e) (keep-first-n '(a b c d e) 5))
(test-equal '(a) (keep-first-n '(a b c d e) 1))
(test-equal '(d) (keep-first-n '(d) 1))
