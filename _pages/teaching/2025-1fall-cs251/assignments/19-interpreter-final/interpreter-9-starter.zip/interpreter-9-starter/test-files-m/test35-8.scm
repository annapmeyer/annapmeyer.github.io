(or #t #f)
