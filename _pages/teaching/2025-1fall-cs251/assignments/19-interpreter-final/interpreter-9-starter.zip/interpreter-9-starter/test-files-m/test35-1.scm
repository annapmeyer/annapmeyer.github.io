(and #f #t)
