(or #t #t)

