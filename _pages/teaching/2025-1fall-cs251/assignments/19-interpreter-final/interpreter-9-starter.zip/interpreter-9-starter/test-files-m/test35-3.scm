(and #t #t)
