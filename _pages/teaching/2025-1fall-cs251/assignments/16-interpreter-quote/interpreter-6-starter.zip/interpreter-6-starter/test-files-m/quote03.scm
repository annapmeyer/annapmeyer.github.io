(quote ())
