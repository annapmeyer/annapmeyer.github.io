#ifndef _SCHEMEITEM
#define _SCHEMEITEM

typedef enum {
  INT_TYPE, DOUBLE_TYPE, STR_TYPE, CONS_TYPE, EMPTY_TYPE, PTR_TYPE
} itemType;

typedef struct SchemeItem {
    itemType type;
    union {
        int i;
        double d;
        char *s;
        struct {
            struct SchemeItem *car;
            struct SchemeItem *cdr;
        };
        void *ptr;
    };
} SchemeItem;

#endif
