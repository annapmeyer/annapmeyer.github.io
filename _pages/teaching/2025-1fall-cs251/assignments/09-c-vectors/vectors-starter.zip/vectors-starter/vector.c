/* You'll add your code in this file. For part 1, *do not* change
   anything about the struct definition or typedef in this file.
   (For part 2, you'll delete these.)  */

struct Vector
{
    // A pointer to a traditional C array to hold data
    int *array;

    // The size of the actual C array that you have allocated
    int memorySize;

    // The virtual size of the vector, i.e. how much data is in it
    // from the user's perspective
    int size;
};

/* Typing "struct Vector" all the time is cumbersome, this sets it up so you can
 just type "Vector" instead. */
typedef struct Vector Vector;

