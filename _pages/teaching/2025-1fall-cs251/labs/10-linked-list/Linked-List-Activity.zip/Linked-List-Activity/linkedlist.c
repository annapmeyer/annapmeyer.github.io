#include <stdlib.h>
#include <stdio.h>
struct Node {
    int item;
    struct Node *next;
};
typedef struct Node Node;



int main() {
    Node *head;//Can use Node instead of struct Node because of typedef above
    head = malloc(sizeof(Node));
    head->item = 1;
    
    head->next = malloc(sizeof(Node));
    head->next->item = 2;
    head->next->next = NULL;
    
    printf("head item: %i\n", (*head).item);//(*head).item is equivalent to head->item
    printf("head->next item: %i\n", (*((*head).next)).item);//equivalent to head->next->item

    free(head->next);
    free(head);
}
