#include <stdlib.h>
#include <stdio.h>

/*
    Function that returns a double and takes two integer parameters. We get to choose what it does!
*/
double TODO1(int val1, int val2) {
    // TODO: implement this function so that it does something interesting.
    // Then call combine and pass in this function as input.
    return 0.0;
}

/*
    Input: *fn (pointer to a function, this function takes two integers as input
                and returns a double)
           val1, integer
           val2, integer
    Behavior: calls *fn(val1, val2) and prints the result.
*/
void combine() {
    // TODO: fill in this function and update its return type and parameters
}

// Multiply num by 3
int triple(int num) {
    return num*3;
}

// Compute the square of num
int square(int num) {
    return num*num;
}

/*
    Input: val (integer) 
           *fn (pointer to a function, this function takes one integer 
                    as input and returns an integer)
    Output: apply val to fn and print the result
*/
void transform(int val, int (*fn)(int)) {
    int result = (*fn)(val);
    printf("Result: %i\n", result);
}


int main() {
    // TODO: what happens if we remove & before triple and square?
    transform(4, &triple);
    transform(4, &square);
}