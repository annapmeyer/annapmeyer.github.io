#include <stdlib.h>
#include <stdio.h>

void *map() {
    // TODO write this function and fill in the return type/parameters
}

/*
 * Fill the first length entries of array with
 * doubles that are one apart, beginning at startValue.
 */
void fillArray(double *arr, int startValue, int length) {
    for(int i = 0; i < length; i++) {
        arr[i] = startValue + i;
    }
}

/*
 * Prints the first length entries of the
 * array arr of doubles.
 */
void printArray(double *arr, int length) {
    printf("[");
    for(int i = 0; i < length; i++) {
        printf("%f", arr[i]);
        if (i < length - 1) {
            printf(",");
        }
    }
    printf("]\n");
}

int main() {
    int length = 10;
    double *array1 = malloc(sizeof(double)*10);
    fillArray(array1, 1, length);

    printArray(array1, length);

    free(array1);
}