import sys 

SIDE_SPLITTER = '->'
EPSILON = 'epsilon'
END_OF_STRING_MARKER = '$'

class Grammar:
    '''
    Class representing a CFG, with methods to create an LL(1) parsing table
    (including printing out if the grammar is not LL(1) parseable).
    '''

    def __init__(self, grammarFile):
        '''
        Read the grammar from grammarFile to initialize
        lists of non-terminals, terminals, and rules. Each
        rule represented as a tuple where first item is a single 
        non-terminal representing the lefthand side of the rule and 
        the second item is a listrepresenting the elements of the
        righthand side of the rule.
        '''
        self.startSymbol = None
        self.nonTerminals = set()
        self.terminals = set()
        self.rules = []
        with open(grammarFile, 'r') as f:
            for line in f:
                if line.startswith('#') or line.strip() == "":
                    continue
                lhs, rhs = line.split(SIDE_SPLITTER)
                lhs = lhs.strip()
                if self.startSymbol is None:
                    self.startSymbol = lhs
                self.nonTerminals.add(lhs)
                rhsSplit = [element.strip() for element in rhs.split(',')]
                self.rules.append((lhs, rhsSplit))
        
        # Everything that isn't epsilon or a non-terminal is a termnal
        for rule in self.rules:
            for rhsElement in rule[1]:
                if rhsElement not in self.nonTerminals and rhsElement != EPSILON:
                    self.terminals.add(rhsElement)

        
        
    def makeGrammarTable(self):
        '''
        Creates a grammar table represented as a dictionary
        where keys are non-terminals and values are dictionaries
        that have terminals (or end of string marker) as keys
        and a list of rules as values. (More than one rule in the
        list means not LL(1) parseable!)
        '''
        firstSets = self.makeFirstSets()
        followSets = self.makeFollowSets(firstSets)

        table = {nonTerminal : {} for nonTerminal in self.nonTerminals}

        for rule in self.rules:
            lhs, rhs = rule
            firstSetForRHS = self.getFirstSetForSequence(rhs, firstSets)
            for firstitem in firstSetForRHS:
                if firstitem == EPSILON:
                    # Delete the pass below and put your code here to 
                    # add to the table if epsilon is in the first set for
                    # the right side
                    pass
                else:
                    # Delete the pass below and put your code here to 
                    # add to the table for a non-epsilon element of 
                    # the first set
                    pass
        return table

    def printGrammarTable(self, tableFile):
        '''
        Makes a grammar table and prints it to the file tableFile.
        Representation is to put the original grammar in comments,
        then print the start symbol marked by "start", and then
        to print each non-empty cell in the form of row (non-terminal),
        a space, column (terminal), a space, and then the right hand side
        of the rule with elements separated by spaces. 
        '''
        table = self.makeGrammarTable()
        # First, write the rules as comments
        with open(tableFile,'w') as f:
            f.write('# Grammar rules\n')
            for rule in self.rules:
                f.write('# ' + rule[0] + " " + SIDE_SPLITTER + " " + " ".join(rule[1]) + "\n")

            # Then write the start symbol
            f.write("start " + self.startSymbol + "\n")

            # Then write the table
            for nonTerminal in table:
                for terminal in table[nonTerminal]:
                    rules = table[nonTerminal][terminal]
                    if len(rules) > 1:
                        print("Error! Not LL(1) parseable.")
                    
                    for rule in rules:
                        rhsString = " ".join(rule[1])
                        if EPSILON in rule[1]:
                            # Write an actual blank
                            rhsString = ""
                        f.write(nonTerminal + " " + terminal + " " + rhsString + "\n")


    def getFirstSetForSequence(self, lst, firstSets):
        '''
        Returns the first set for a sequence with the elements in lst.
        If lst is empty, returns a first set with just EPSILON.

        lst: list of terminals and/or non-terminals, or a single epsilon
        firstSets: dictionary with non-terminals as keys, sets as values
        '''
        firstSet = set()
        for item in lst:
            if item in self.terminals:
                return firstSet.union(set([item]))
            elif item in self.nonTerminals:
                firstSet, _ = unionIntoSetWithoutEpsilon(firstSet, firstSets[item])
                if EPSILON not in firstSets[item]:
                    return firstSet
        # Reaching here means that epsilon was in all first sets
        return firstSet.union(set([EPSILON]))
        
    def makeFirstSets(self):
        '''
        Returns the first sets for all nonterminals in the grammar.
        First sets represented as a dictionary with non-terminals as keys, sets as values
        '''
        firstSets = {nonTerminal : set() for nonTerminal in self.nonTerminals}
        rulesForUpdatingSets = []
        # Initialize the sets based on rules that start with a terminal
        for rule in self.rules:
            lhs, rhs = rule
            if rhs[0] in self.terminals:
                firstSets[lhs].add(rhs[0])
            else:
                rulesForUpdatingSets.append(rule)
                
        changes = True
        while changes:
            changes = False
            for rule in rulesForUpdatingSets:
                newChanges = self.updateFirstSets(rule, firstSets)
                changes = newChanges or changes
                
        return firstSets
    
    def updateFirstSets(self, rule, firstSets):
        '''
        Mutate firstSets based on the given rule. Returns
        True if any first set changed (i.e., elements that were
        not already present were added) and False otherwise.
        
        rule: tuple where first item is a single non-terminal representing
              the lefthand side of the rule and the second item is a list
              representing the elements of the righthand side of the rule.
        firstSets: dictionary with non-terminals as keys, sets as values
        '''
        allItemsNullable = True
        lhs, rhs = rule # unpack the two sides of the rule
        initFirstSetLength = len(firstSets[lhs])
        for item in rhs:
            # Delete the pass below and put your code here to correctly update the first sets
            pass

        if allItemsNullable:
            firstSets[lhs].add(EPSILON)
        return initFirstSetLength != len(firstSets[lhs])
    
    def makeFollowSets(self, firstSets):
        '''
        Returns the follow sets for all non-terminals in the grammar.
        Follow sets represented as a dictionary with non-terminals as keys, sets as values

        firstSets: all first sets for non-terminals, represented as a 
                   dictionary with non-terminals as keys, sets as values
        '''
        followSets = {nonTerminal : set() for nonTerminal in self.nonTerminals}
        # Initialize the sets based on non-terminals immediately followed by a terminal
        for rule in self.rules:
            _, rhs = rule # Unpack the rule - we only need the right side
            for i in range(len(rhs) - 1): #We'll be looking at the item after the current, so skip the last
                if rhs[i] in self.nonTerminals and rhs[i+1] in self.terminals:
                    followSets[rhs[i]].add(rhs[i+1])
        
        # Add the $ for end of string
        followSets[self.startSymbol].add(END_OF_STRING_MARKER)
        
        # Iteratively update
        changes = True
        while changes:
            changes = False
            for rule in self.rules:
                newChanges = self.updateFollowSets(rule, followSets, firstSets)
                changes = newChanges or changes
                
        return followSets

    
    def updateFollowSets(self, rule, followSets, firstSets):
        '''
        Mutate followSets based on the given rule. Returns
        True if any follow set changed (i.e., elements that were
        not already present were added) and False otherwise.
        
        rule: tuple where first item is the left hand side (a non-terminal)
              and the second item is a list of the elements on the right hand side
        followSets: dictionary with non-terminals as keys, sets as values 
        firstSets: dictionary with non-terminals as keys, sets as values that
                    represents the pre-computed first sets for all non-terminals
        '''
        lhs, rhs = rule # unpack the two sides of the rule
        anyChanges = False
        
        for i in range(len(rhs)): #Depending on how you implement, you may or may not want to adjust the range
            # Delete the pass below and put your code here to correctly update the follow sets
            pass
        return anyChanges
                
            


    
    def isNullableSequence(self, lst, firstSets):
        '''
        Returns True if lst is empty or every element in lst
        is a non-terminal whose first set contains epsilon.

        lst: list of terminals and/or non-terminals [cannot contain epsilon]
        firstSets: dictionary with non-terminals as keys, sets as values
        '''
        allNullable = True
        for item in lst:
            if item in self.terminals or EPSILON not in firstSets[item]:
                allNullable = False
        return allNullable
            
def unionIntoSetWithoutEpsilon(setToUnionInto, setToAdd):
    '''
    Returns a new set that is the union of setToUnionInto and (setToAdd - {epsilon}).
    (Note that if epsilon is not in setToAdd, then setToAdd - {epsilon} is equal to
    epsilon.)

    setToUnionInto: a set
    setToAdd: a set
    '''
    setToUnionIn = setToAdd - set([EPSILON])
    newSet = setToUnionInto.union(setToUnionIn)
    return newSet, len(newSet) != len(setToUnionInto)

def addToTable(table, row, col, rule):
    '''
    Mutates table to add the rule to the list in the cell
    (row, col) of table.

    table: dictionary with dictionaries as values. The inner
           dictionaries should have lists as values.
    row: first key for table
    col: second key for table
    rule: element to add at (row, col)
    '''
    if col not in table[row]:
        table[row][col] = []
    table[row][col].append(rule)


def main():
    if len(sys.argv) < 2:
        print("Usage: python3 inputGrammarFile tableFile")
        print("Reads in inputGrammarFile as a CFG and if another " +
              "input is provided, writes the grammar table to that file")
        sys.exit()

    grammar = Grammar(sys.argv[1])

    # First, add some lines of code below to print out
    # the instance variables of grammar. One line has been
    # added as an example.
    print("terminals:", grammar.terminals)

    # Once you've implemented updateFirstSets, uncomment the 
    # lines below to try it out

    # firstSets = grammar.makeFirstSets()
    # print("firstSets:", firstSets)

    # Once you've implemented updateFollowSets, uncomment the 
    # lines below to try it out

    # followSets = grammar.makeFollowSets(firstSets)
    # print("followSets:", followSets)

    # Once you've implemented makeGrammarTable, uncomment the 
    # lines below to try it out

    # table = grammar.makeGrammarTable()
    # print("table:", table)
    # if len(sys.argv) >= 3:
    #     grammar.printGrammarTable(sys.argv[2])


  
if __name__ == "__main__":
    main()
            
