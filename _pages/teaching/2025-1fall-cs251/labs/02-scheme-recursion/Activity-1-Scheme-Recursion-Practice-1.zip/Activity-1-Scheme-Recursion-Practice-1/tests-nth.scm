;; DO NOT CHANGE THESE TESTS.

;; Module to include testing code
(use-modules (srfi srfi-64))


(test-equal "nth1" (nth 1 '(2 3 5)) 2)
(test-equal "nth2" (nth 1 '()) '())
(test-equal "nth3" (nth 10 '(2 3 5)) '())
(test-equal "nth4" (nth -5 '(2 3 5)) '())
(test-equal "nth5" (nth 1 '((1 2) 7)) '(1 2))
(test-equal "nth6" (nth 2 '((1 2) 7)) 7)
(test-equal "nth7" (nth 4 '(2 3 5 7 9)) 7)