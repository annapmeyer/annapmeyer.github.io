;; DO NOT CHANGE THESE TESTS.

;; Module to include testing code
(use-modules (srfi srfi-64))

(test-equal "get-last-1" (get-last '(13)) 13)
(test-equal "get-last-2" (get-last '()) '())
(test-equal "get-last-3" (get-last '((1 2) 7)) 7)
(test-equal "get-last-4" (get-last '((1 2) 7 (3 4) 56)) 56)
