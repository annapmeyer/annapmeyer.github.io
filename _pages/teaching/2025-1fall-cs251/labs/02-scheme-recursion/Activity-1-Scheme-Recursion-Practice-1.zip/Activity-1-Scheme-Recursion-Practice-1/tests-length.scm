;; DO NOT CHANGE THESE TESTS.

;; Module to include testing code
(use-modules (srfi srfi-64))

(test-equal "length1" (list-length '(2 3 5)) 3)
(test-equal "length2" (list-length '()) 0)
(test-equal "length3" (list-length '((1 2) 7)) 2)

