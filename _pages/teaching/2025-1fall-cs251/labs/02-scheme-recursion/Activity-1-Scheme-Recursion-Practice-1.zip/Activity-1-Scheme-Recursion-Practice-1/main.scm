

;; For the part about if (put other functions above here)
(define example-fn
    (lambda (unused) 
        #t))