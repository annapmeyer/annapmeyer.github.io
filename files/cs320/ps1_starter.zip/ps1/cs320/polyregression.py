"""
    Starter file for polynomial regression.
    Originally created by Anna Rafferty (as a modification of materials from UW)
"""

import numpy as np

class PolynomialRegression:
    def __init__(self, degree = 1, reg_lambda = 1e-8):
        """
        Constructor

        Inputs:
        - degree: int representing the maximal degree of the feature
              function.
        - reg_lambda: float representing the amount of regularization
              we'll use when fitting the weights.
        """
        self.degree = degree
        self.reg_lambda = reg_lambda
        self.weights = None  
        # You can add additional fields if you like
        pass


    def fit(self, X, y):
        """
        Trains the model, and saves learned weights in self.weights

        Inputs:
            - X: np array of shape (N, 1) with observations.
            - y: np array of shape (N, 1) with targets.

        Returns:
            - None

        Note:
            You will need to apply polynomial expansion and data standardization first.
        """
        # Implement the function here. This will include applying the polynomial
        # expansion, standardizing the features, and adding a constant feature that's always
        # 1 as the initial feature (so that you'll learn an intercept - w_0 in the description).
        # You should make sure to standardize the features: for all non-constant features, 
        # center them at 0, and divide by the standard deviation (ask yourself: why do we do this?).
        # Save the information you need to apply the same standardization to test points. 
        # I've provided a function compute_weights that you may call to fit the weights,
        # under the assumption that notebook 1 gave you good practice implementing gradient descent.
        # If you want more practice, you can implement gradient descent yourself!
        #
        # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****
        pass # Delete this and write your own code

        # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****

    def predict(self, X):
        """
        Use the trained model to predict values for each instance in X.

        Inputs:
            - X: np array of shape (N, 1) with observations.

        Returns:
            - an np array of shape (N, 1) with predictions.
        """
        # Notes: don't forget to generate the polynomial features and to
        # standardize the features! To perform a matrix multiplication, you
        # can use @. E.g., A @ b is Ab: it will multiply the matrix A by b.
        # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****

        pass # Delete this and write your own code


        # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****


# Note that this method is outside of the class definition because it doesn't
# use any of the instance variables. (Another way of writing this would have
# been to make it a static method inside of the PolynomialRegression class,
# but my guess is that many folks haven't seen static methods in python.)
def polyfeatures(X, degree):
    """
    Expands the given X into an (N, degree) array of polynomial features of degree degree.

    Inputs:
        - X: np array of shape (N, 1).
        - degree: Positive integer defining maximum power to include.

    Returns:
        -  An (N, degree) numpy array, with each row comprising of
            X, X * X, X ** 3, ... up to the degree^th power of X.
            Note that the returned matrix will not include the zero-th power.

    """
     # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****

    pass # delete this and write your own code

    # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****


def compute_weights(X, y, reg_lambda):
    '''
    Computes the weights that minimize the objective analytically
    (using linear algebra). You do not need to change this function.
    You may call this function in your code to get the weights. Note
    that this function does not add an intercept: it assumes there is
    a constant feature as the first column in X.

    If you prefer not to call this function, you may implement gradient 
    descent or an analytical solution to get your weights. 
    If you do so, you should not use any packages other than pandas, numpy, 
    and/or scipy.

    Inputs:
    - X: np array of shape (N, d).
    - y: np array of shape (N,).
    - reg_lambda: float representing the amount of regularization

    Returns:
    - np array of shape (d,) with the weights for the linear model.
    '''
    # construct regularization matrix as a diagonal matrix
    # with the regularization lambda on the diagonal.
    reg_matrix = reg_lambda * np.eye(X.shape[1])
    # the intercept does not get regularized
    reg_matrix[0, 0] = 0

    # analytical solution finds the exact value for the weights:
    # that value is: (X'X + regMatrix)^-1 X' y
    weights = np.linalg.solve(X.T @ X + reg_matrix, X.T @ y)
    return weights


def mean_squared_error(a, b):
    """Given two arrays: a and b, both of shape (N, 1), calculate a mean squared error.

    Inputs:
        a: np array of shape (N, 1)
        b: np array of shape (N, 1)

    Returns:
        float: mean squared error between a and b.
    """
    # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****

    pass # delete this and write your own code

    # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****


def learning_curve(
    Xtrain: np.ndarray,
    ytrain: np.ndarray,
    Xtest: np.ndarray,
    ytest: np.ndarray,
    reg_lambda: float,
    degree: int,
):
    """
    Compute learning curves: training and test error as the number
    of training points varies.

    Inputs:
        - Xtrain: Training observations, np array of shape: (N, 1)
        - ytrain: Training targets, np array of  shape: (N, 1)
        - Xtest: Testing observations, np array of shape: (N, 1)
        - ytest: Testing targets, np array of shape: (N, 1)
        - reg_lambda: Regularization factor (float)
        - degree: Polynomial degree (int)

    Returns:
        - Tuple of two numpy arrays. The two elements of this tuple are:
            1. error_train: error_train[i] is the training mean squared error using model trained by Xtrain[0:(i+1)]
            2. error_test: error_test[i] is the testing mean squared error using model trained by Xtrain[0:(i+1)]

    Note:
        - For errorTrain[i] only calculate error on Xtrain[0:(i+1)], since this is the data used for training.
            THIS DOES NOT APPLY TO errorTest (always calculate the test error on the whole test dataset).
        - errorTrain[0:1] and errorTest[0:1] won't actually matter, since we start displaying the 
           learning curve at N = 2 (or higher).
           Thus, you can start your loop with filling in error_train[1] and using the first 2 training data points 
           rather than filling in error_train[0] and using only the first training points. (Doing the latter may
           lead you to see a run time warning from your scaling code.)
        - The code as written will return a tuple - this is simply putting two things with a comma between them
    """
    n = len(Xtrain)

    error_train = np.zeros(n)
    error_test = np.zeros(n)
    # Write a loop below that will fill in the error_train and error_test arrays
    # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****
    pass # Delete this and write your own code

    # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****
    return error_train, error_test
