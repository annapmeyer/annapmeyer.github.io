"""
    Plotting utilities for polynomial regression.
    Modified from materials from UW.
    You do not need to modify (or even look at!)
    this file.
"""
import numpy as np
import matplotlib.pyplot as plt
from sklearn import model_selection
import cs320.polyregression as polyregression


def plot_learning_curve(error_train, error_test, reg_lambda, degree):
    """
        Plot computed learning curve
    """
    minX = 4
    maxY = max(error_test[minX :])

    xs = np.arange(len(error_train))
    plt.plot(xs, error_train, "r-o", label="Training Error")
    plt.plot(xs, error_test, "b-o", label="Testing Error")
    plt.plot(xs, np.ones(len(xs)), "k--")
    plt.title(f"d={degree}, lambda={reg_lambda}")
    plt.xlabel("Training samples")
    plt.ylabel("Mean-squared error")
    plt.yscale("log")
    plt.ylim(top=maxY)
    plt.xlim((minX, 10))


def generate_learning_curve(X, y, degree, reg_lambda):
    """
        Computing learning curve via leave one out CV
    """
    n = len(X)

    error_trains = np.zeros((n, n - 1))
    error_tests = np.zeros((n, n - 1))

    loo = model_selection.LeaveOneOut()
    itrial = 0
    for train_index, test_index in loo.split(X):
        X_train, X_test = X[train_index], X[test_index]
        y_train, y_test = y[train_index], y[test_index]

        (err_train, err_test) = polyregression.learning_curve(
            X_train, y_train, X_test, y_test, reg_lambda, degree
        )

        error_trains[itrial, :] = err_train
        error_tests[itrial, :] = err_test
        itrial = itrial + 1

    plot_learning_curve(error_trains.mean(axis=0), error_tests.mean(axis=0), reg_lambda, degree)