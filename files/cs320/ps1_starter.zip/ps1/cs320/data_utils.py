import io
import numpy as np
import os
import pandas as pd
import pickle
import requests

''' 
Utilities for loading datasets. You do not need to modify (or even 
look at!) this file. 
'''

def load_CIFAR_batch(url):
    '''
    Load the CIFAR data stored at the given URL
    '''
    try:
        response = requests.get(url)
        response.raise_for_status() 
        binary_stream = io.BytesIO(response.content) 
        datadict = pickle.load(binary_stream, encoding="latin1")
        print("Pickle file loaded successfully!")

        X = datadict["data"]
        y = datadict["labels"]
        X = X.reshape(10000, 3, 32, 32).transpose(0, 2, 3, 1).astype("float")
        y = np.array(y)
        return X, y

    except requests.exceptions.RequestException as e:
        print(f"Error fetching data from URL: {e}")
    except pickle.UnpicklingError as e:
        print(f"Error unpickling the data: {e}. Check if the file is a valid pickle file. ")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
    return [], []

def load_CIFAR10():
    '''
    Load the train (first 10000 samples) and test datasets of CIFAR-10
    '''
    url_train = "https://drive.google.com/uc?export=download&id=12Z2GiSLxx0URLIJyy3Crzl2If4iHegxn"
    url_test = "https://drive.google.com/uc?export=download&id=134XkXPLxz2JUC2t9NZYkrImmenPWmzhj"
    Xtr, ytr = load_CIFAR_batch(url_train)
    Xte, yte = load_CIFAR_batch(url_test)
    return Xtr, ytr, Xte, yte

def load_data(data_path):
    '''
    Load data for polynomial regression
    '''
    f = open(os.path.join(data_path,"datasets", "polydata.dat"), "r")
    allData = np.loadtxt(f, delimiter=",")
    f.close()
    return allData

def load_data_ad():
    '''
    Load data for Part 1 (linear regression)
    '''
    url = "https://drive.google.com/uc?export=download&id=1zyWv0iq18QBLmCC1wTeNaQgpY1YjxjFc"

    try:
        response = requests.get(url)
        response.raise_for_status() 
        binary_stream = io.BytesIO(response.content) 
        df = pd.read_csv(binary_stream)
        return df
    
    except requests.exceptions.RequestException as e:
        print(f"Error fetching data from URL: {e}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

    return None