import numpy as np
import pandas as pd

import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

from cs320.data_utils import load_data_ad

def compute_theta(X: np.ndarray, y: np.ndarray): 
    '''
    Compute the closed-form analytical solution to linear regression
    '''
    ##############################################################
    # TODO: use numpy to compute (X^T X)^{-1} X^T y              # 
    # Hint: Use an interpreter or the ipynb to test out the      #
    # multiplication steps. Looking at the shape of the matrices # 
    # and arrays will be helpful. Remember that to multiply two  # 
    # matrices A and B (i.e., C = AB), A must have dimensions    #
    # (m, n) and B must have dimensions (n, p). The new matrix C #
    # will then have dimensions (m, p).                          #
    ##############################################################
    # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****

    # More hints: use A.T to compute the transpose of A
    # Use np.linalg.inv(A) to compute the inverse of a matrix
    # Use np.matmul(A, B) to multiply two matrices

    theta = None # replace this line with your code

    # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****
    return theta

def plot_model_preds(y_pred_train, y_pred_test, y_train, y_test):

    # Create a scatter plot with ground truth sales on the x-axis and 
    # predicted sales on the y-axis 
    plt.scatter(y_train, y_pred_train, color='red', marker='o')
    plt.scatter(y_test, y_pred_test, color='blue', marker='x')

    plt.xlabel('Ground Truth Sales')
    plt.ylabel('Predicted Sales')
    plt.title('Predicted vs Ground Truth Sales')

    # Create a line of y=x for reference
    plt.plot([np.min(y_pred_train)-1, np.max(y_pred_train) + 1], [np.min(y_pred_test)-1, np.max(y_pred_test) + 1], 'k--', lw=2) 
    return plt



def load_data_single_split(random_state: int=0):
    ''' 
    Load the data and return a single train/test split.
    '''
    # load the dataframe using the utility function
    df = load_data_ad()

    # create train and test datasets
    # test_size=0.2 means 20% of data will be used for testing
    # random_state=0 ensures we get the same split every time
    df_train, df_test = train_test_split(df, test_size=0.2, random_state=random_state)

    #######################################################
    # TODO: separate out the features (X) and labels (y). # 
    # Then convert each of X_train, X_test, y_train,      #
    # y_test to numpy arrays.                             #
    #######################################################
    # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****
    
    X_train = None
    y_train = None
    X_test = None
    y_test = None

    # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****

    # Standardize the features (mean 0, std 1) using sklearn's StandardScaler
    # In Part 2 of this assignment, you will implement this step by hand. For 
    # now, just use the library.
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)
    y_scaler = StandardScaler()
    y_train = y_scaler.fit_transform(y_train)
    y_test = y_scaler.transform(y_test)

    return X_train, y_train, X_test, y_test

def load_data_crossval(num_splits: int):
    '''
    Load the data and return multiple cross-validation splits.
    '''
    # load the dataframe using the utility function
    df = load_data_ad()

    X_train, y_train, X_test, y_test = load_data_single_split(random_state=0)

    # X_test and y_test will remain fixed! (Can't mix train and test data across k-folds)

    # We will create list of all the X_train splits, y_train splits, etc.
    Xs_train = []
    ys_train = []
    Xs_val = []
    ys_val = []
    Xs_test = []
    ys_test = []

    #######################################################################
    # TODO: write a loop that will create train - val - test splits and   #
    # add them to the appropriate lists. You should use k-fold cross      #
    # validation. Divide X into k folds. Hint: Look up the numpy          #
    # array_split function in the official numpy documentation. You may   #   
    # also find the function np.concatenate useful for combining folds.   # 
    # For each fold, use it as validation data once and use the remaining #
    # folds as training data.                                             #
    #######################################################################
    # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****

    X_folds = None
    y_fold = None 



    # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****
    
    # Standardize the features (mean 0, std 1) using sklearn's StandardScaler
    # In Part 2 of this assignment, you will implement this step by hand. For 
    # now, just use the library.
    for i in range(num_splits):
        scaler = StandardScaler()
        Xs_train[i] = scaler.fit_transform(Xs_train[i])
        Xs_val[i] = scaler.transform(Xs_val[i])
        Xs_test.append(scaler.transform(X_test))
        y_scaler = StandardScaler()
        ys_train[i] = y_scaler.fit_transform(ys_train[i])
        ys_val[i] = y_scaler.transform(ys_val[i])
        ys_test.append(y_scaler.transform(y_test))
    
    return Xs_train, ys_train, Xs_val, ys_val, Xs_test, ys_test
    


def load_data(num_splits : int = 1):
    '''
    Wrapper function to load the data. num_splits indicates whether we should 
    return multiple cross-validation splits or just a single train/test split.
    '''
    if num_splits == 1:
        return load_data_single_split()
    else:
        return load_data_crossval(num_splits)


def get_mse(y_pred, y_true) -> float:
    '''
    Given a linear regression model, compute the MSE on dataset (X, y)
    '''

    accuracy = -1

    # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****
    
    # Put your code here

    # ******END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)******
    return accuracy