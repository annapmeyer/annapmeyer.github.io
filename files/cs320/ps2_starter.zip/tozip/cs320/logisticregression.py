'''
Starter code for the logistic regression classifier. You
may add additional methods or functions if you wish. You
should not use libraries other than numpy or pandas.
'''
import numpy as np


class LogisticModel:

    def __init__(self):
        '''
        Constructor.

        You may change this if you wish.
        '''
        self.weights = None

    def train(self, X, y, step_size, num_iterations):
        '''
        Uses logistic regression to train the model, with 
        input data X and expected outputs y. After training,
        an instance variable for the class should store the 
        weights found via gradient descent.


        Inputs:
        - X: A numpy array of shape (N,D) containing a dataset. N is the
              number of data points, and D is the number of features.
        - y: A numpy array of shape (N,) containing the true labels for the same
            data points
        - step_size: a float representing the step size to use for logistic
            regression
        - num_iterations: an int representing the number of iterations of
            gradient descent to perform

        Returns:
        - loss_per_iteration: a numpy array of shape (num_iterations,) with
            the average logistic loss for points in X at each iteration of training.
        '''
        np.random.seed(320) # Make the random number generator always produce
                            # the same initialization for HW reproducibility
        self.weights = 2*np.random.rand(1 + X.shape[1]) - 1 # Initialize the weights
                                                        # to a number in [-1,1)
        # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****
        losses = None 
            
        # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****
        return losses


    def predict(self, X):
        '''
        Uses the stored weights to make predictions for the items in X.

        Inputs:
        - X: A numpy array of shape (N,D) containing a dataset.
    
        Returns:
        - predictions: a numpy array of shape (N,) with the classifier's
            prediction for each point in X. If the classifier has not already
            been trained, returns None instead.
        '''
        # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****
        pass # remove this line
        # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****



    def get_weights(self):
        '''
        Get the weights for the logistic classifier.

        Returns:
        - weights: numpy array of shape (D+1,) with the weights for the 
            logistic regression classifier, or None if the classifier
            has not been trained.
        '''
        # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****
        pass # remove this line
        # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****


    def get_average_loss(self, X, y):
        '''
        Computes the average logistic loss function for points in X when
        predictions are made by this classifier.
        (i.e., if X has 70 data points, this is the total logistic loss divided by 70).

        Inputs:
        - X: A numpy array of shape (N,D) containing a dataset.
        - y: A numpy array of shape (N,) containing the true labels for the same
            data points

        Returns:
        - avg_loss: a float representing the average loss
        '''
        # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****
        pass # remove this line
        # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****


