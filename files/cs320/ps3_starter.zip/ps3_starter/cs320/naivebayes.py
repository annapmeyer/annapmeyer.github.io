import numpy as np
import pandas as pd 

UNSEEN_FEATURE_VALUE_KEY = "feat-val-unseen"
class NaiveBayes:

    def __init__(self):
        pass
        self.probs = None
        self.prior = None

    def get_feature_probabilities(self, label, feature):
        '''
        Returns the probability distribution over the input feature
        given that the class is equal to label. Returns None if the
        class has not been trained or if label or feature are invalid.

        Inputs:
        - label: the name of a particular class (e.g., if classification options are dog
           or cat, then label is either dog or cat)
        - feature: the name of a particular feature (*not* a value for that feature)

        Returns:
        - a dictionary-like object representing the probability distribution p(Feature | class = label)
        '''
        if self.probs is not None:
            cond_probs = self.probs.get(label, None)
            if cond_probs is not None:
                return cond_probs.get(feature, None)
        return None
    
    def get_class_probabilities(self):
        '''
        Returns the probability distribution over values of the classes. Returns None
        if the class has not been trained.

        Returns:
        - a dictionary-like object representing the probability distribution p(Class)
        '''
        return self.prior

    def train(self, train_df, train_labels, smoothing_amount=1):
        '''
        Train a naive bayes model with laplace smoothing. Learns the probability
        distribution of the classes and of each feature value (conditional on each class)
        
        Inputs
        - train_df: Training data (features)
        - train_labels: Training data labels
        - smoothing_amount: Parameter for smoothing (how many of each observation to add to totals)

        Outputs - None. Save weights to self.prior (for class distributions) and 
                  self.probs (for feature_distributions)
        '''
        self.probs = {}
        self.prior = {}
        for label in train_labels.unique():
            self.probs[label] = {} # Dictionary of feature values for each class
            cur_class_data = train_df[train_labels==label]
            
            self.prior[label] = (cur_class_data.shape[0] + smoothing_amount) / (train_df.shape[0] + smoothing_amount*len(train_labels.unique()))
            for feat_name in train_df.columns:
                self.probs[label][feat_name] = {}
                counts = cur_class_data[feat_name].value_counts().to_dict()
                counts[UNSEEN_FEATURE_VALUE_KEY] = 0
                total = cur_class_data.shape[0] + len(counts)*smoothing_amount
                # START OF YOUR CODE
                ## Add code here to turn these counts into a probability distribution.
                ## You should save Pr(F_j = k | class = c) into self.probs[c][fj][k]


                # END OF YOUR CODE
        pass

    def get_distribution_over_classes(self, new_data_point):
        '''
        Get the probability distribution for classifying a new sample 
        
        Inputs:
        - new_data_point: New sample that we want to classify

        Returns:
        - the probability distribution that new_data_point belongs to each class 
        '''
        distribution = {label : 0 for label in self.probs}
        # START OF YOUR CODE
        # Your task is to compute the probability that new_data point belongs to each
        #            class given its features.
        # You should store P(Class=c, new_data_point[f1], new_datapoint[f2]) in distribution[c]
        # Hint: Check if a dictionary has a key using "if key in C" notation. You can use this to figure out when to 
        #       apply UNSEEN_FEATURE_VALUE_KEY


        # END OF YOUR CODE
        
        # This code handles all of the numerical underflow and normalization
        max_val = -10000000
        for label in distribution:
            if distribution[label] > max_val:
                max_val = distribution[label]
        distribution = {label : np.exp(val - max_val) for label, val in distribution.items()}

        total = sum(distribution.values())
        normalized_distribution = {label : val / total for label, val in distribution.items()}
        return normalized_distribution
    
    def predict(self, df):
        records = []
        for i in range(df.shape[0]):
            records.append(self.get_distribution_over_classes(df.iloc[i,:]))
        return pd.DataFrame.from_records(records)
    
def compute_accuracy(predicted_dists, correct_labels):
    '''
    Computes the proportion of the correct labels where the prediction places 
    '''
    max_prob_class = predicted_dists.idxmax(axis=1)
    return (max_prob_class.to_numpy() == correct_labels.to_numpy()).mean()
