import pandas as pd

def load_adult_data():
    '''
    Read the adult dataset from our shared drive, returning a list where the first item
    is the dataframe for the training dataset and the second item is the dataframe for the
    test dataset. The development dataset is also on drive, but we won't be tuning any
    hyperparameters for this assignment.
    '''
    train_path = 'adult_train_df.csv'
    test_path = 'adult_test_df.csv'
    paths = [train_path, test_path]
    return [pd.read_csv(path) for path in paths]